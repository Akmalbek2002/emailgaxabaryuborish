package com.example.emailgaxabaryuborish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailgaXabarYuborishApplicationTests {

    @Test
    void contextLoads() {
    }

}
