insert into lavozim(lavozimlar)
values
    ('ADMIN'),
    ('MODERATOR'),
    ('USER');