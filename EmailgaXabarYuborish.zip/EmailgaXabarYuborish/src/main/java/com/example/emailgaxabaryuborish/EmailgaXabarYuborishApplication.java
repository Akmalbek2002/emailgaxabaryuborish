package com.example.emailgaxabaryuborish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailgaXabarYuborishApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmailgaXabarYuborishApplication.class, args);
    }

}
