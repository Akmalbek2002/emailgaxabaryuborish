package com.example.emailgaxabaryuborish.entity.Enum;

public enum Lavozimlar {
    ADMIN,
    MODERATOR,
    USER
}
