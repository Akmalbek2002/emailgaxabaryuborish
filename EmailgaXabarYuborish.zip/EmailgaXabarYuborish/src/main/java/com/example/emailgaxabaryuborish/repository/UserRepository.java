package com.example.emailgaxabaryuborish.repository;

import com.example.emailgaxabaryuborish.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<Users,Integer> {
    boolean existsByUsername(String username);
}
