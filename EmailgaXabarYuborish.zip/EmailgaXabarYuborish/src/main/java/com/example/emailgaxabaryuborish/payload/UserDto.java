package com.example.emailgaxabaryuborish.payload;

import lombok.Data;

@Data
public class UserDto {
    private String ism,familiya,telnomer,username,password;
}
